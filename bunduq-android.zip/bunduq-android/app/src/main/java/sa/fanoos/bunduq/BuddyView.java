package sa.fanoos.bunduq;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.View;

import java.util.Random;

/** جسم بندق: حبة بندق كرتونية متحركة (تتمايل، ترمش، تتلفت، تقفز، تتكلم). */
public class BuddyView extends View {
    private static final float DW = 150f, DH = 190f; // مساحة الرسم التصميمية

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Random rnd = new Random();
    private final long t0 = SystemClock.uptimeMillis();

    private long nextBlink = t0 + 2500, blinkUntil, jumpStart, talkUntil, nextGaze;
    private float gx, gy, tgx, tgy;
    private boolean thinking;

    public BuddyView(Context c) {
        super(c);
    }

    public int widthPx() {
        return Ui.dp(getContext(), 92);
    }

    public int heightPx() {
        return Math.round(widthPx() * DH / DW);
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(widthPx(), heightPx());
    }

    public void jump() {
        jumpStart = SystemClock.uptimeMillis();
    }

    public void talk(long ms) {
        talkUntil = SystemClock.uptimeMillis() + ms;
    }

    public void setThinking(boolean b) {
        thinking = b;
    }

    private void oval(Canvas c, float l, float t, float rr, float b, int fill, int stroke, float sw, float dy) {
        r.set(l, t + dy, rr, b + dy);
        if (fill != 0) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(fill);
            c.drawOval(r, p);
        }
        if (sw > 0) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(sw);
            p.setColor(stroke);
            c.drawOval(r, p);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        float t = (now - t0) / 1000f;
        float s = getWidth() / DW;
        c.save();
        c.scale(s, s);
        c.translate(0, 20);

        float bob = (float) Math.sin(t * 2.2) * 4f;
        if (jumpStart > 0) {
            float pr = (now - jumpStart) / 900f;
            if (pr < 1) bob -= (float) Math.abs(Math.sin(pr * Math.PI * 2)) * 20f;
            else jumpStart = 0;
        }
        if (now > nextBlink) {
            blinkUntil = now + 140;
            nextBlink = now + 2500 + rnd.nextInt(3500);
        }
        boolean blink = now < blinkUntil;
        if (now > nextGaze) {
            tgx = rnd.nextFloat() * 7f - 3.5f;
            tgy = rnd.nextFloat() * 6f - 3f;
            nextGaze = now + 1500 + rnd.nextInt(3000);
        }
        gx += (tgx - gx) * 0.15f;
        gy += (tgy - gy) * 0.15f;

        // الظل (لا يتحرك مع التمايل، ويصغر مع القفز)
        float sh = Math.max(0.5f, 1f + bob / 40f);
        oval(c, 75 - 30 * sh, 152, 75 + 30 * sh, 162, 0x40000000, 0, 0, 0);

        float b = bob;
        oval(c, 50, 136, 70, 150, 0xFFC97B2C, 0xFF8A5A2B, 2, b);           // القدمان
        oval(c, 80, 136, 100, 150, 0xFFC97B2C, 0xFF8A5A2B, 2, b);
        oval(c, 28, 50, 122, 146, 0xFFE9A55B, 0xFF8A5A2B, 3, b);           // الجسم
        oval(c, 50, 94, 100, 140, 0xFFF7D7A6, 0, 0, b);                    // البطن

        // القبعة (نصف دائرة علوية)
        r.set(26, 34 + b, 124, 102 + b);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF7A4A23);
        c.drawArc(r, 180, 180, true, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setColor(0xFF5A3417);
        c.drawArc(r, 180, 180, true, p);
        oval(c, 50, 50, 55, 55, 0xFF5A3417, 0, 0, b);
        oval(c, 72, 42, 77, 47, 0xFF5A3417, 0, 0, b);
        oval(c, 95, 50, 100, 55, 0xFF5A3417, 0, 0, b);

        // الساق والورقة
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF5A3417);
        c.drawRect(71, 22 + b, 79, 38 + b, p);
        oval(c, 78, 18, 102, 32, 0xFF7CC36B, 0xFF4F8F42, 2, b);

        // العيون
        if (blink) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3);
            p.setColor(0xFF3B2A1A);
            p.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(48, 87 + b, 68, 87 + b, p);
            c.drawLine(82, 87 + b, 102, 87 + b, p);
        } else {
            oval(c, 46, 74, 70, 100, 0xFFFFFFFF, 0xFF3B2A1A, 2, b);
            oval(c, 80, 74, 104, 100, 0xFFFFFFFF, 0xFF3B2A1A, 2, b);
            oval(c, 53 + gx, 81 + gy, 64 + gx, 94 + gy, 0xFF1D1410, 0, 0, b);
            oval(c, 87 + gx, 81 + gy, 98 + gx, 94 + gy, 0xFF1D1410, 0, 0, b);
            oval(c, 55 + gx, 83 + gy, 59 + gx, 87 + gy, 0xFFFFFFFF, 0, 0, b);
            oval(c, 89 + gx, 83 + gy, 93 + gx, 87 + gy, 0xFFFFFFFF, 0, 0, b);
        }

        // الخدود
        oval(c, 36, 100, 50, 108, 0xFFF28C8C, 0, 0, b);
        oval(c, 100, 100, 114, 108, 0xFFF28C8C, 0, 0, b);

        // الفم
        boolean open = now < talkUntil && (now / 140) % 2 == 0;
        if (open) {
            oval(c, 68, 104, 82, 118, 0xFF7A2A2A, 0xFF3B2A1A, 2, b);
        } else {
            r.set(64, 98 + b, 86, 116 + b);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(0xFF3B2A1A);
            c.drawArc(r, 20, 140, false, p);
        }

        // نقاط التفكير
        if (thinking) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF5A3417);
            int dots = (int) ((now / 330) % 4);
            for (int i = 0; i < dots; i++) c.drawCircle(108 + i * 10, 14, 4, p);
        }

        c.restore();
        postInvalidateDelayed(33);
    }
}
