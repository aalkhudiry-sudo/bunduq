package sa.fanoos.bunduq;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** نافذة الدردشة مع بندق (كتابة أو صوت). */
public class ChatActivity extends Activity {
    private static final int REQ_SPEECH = 7;
    private static final List<String[]> LOG = new ArrayList<>();
    private static boolean busy;
    private static ChatActivity current;

    private LinearLayout list;
    private ScrollView sv;
    private EditText input;
    private Button voiceBtn;
    private TextView thinkingView;

    /** يسجل رسالة في سجل الدردشة ويعرضها إن كانت النافذة مفتوحة. */
    public static void record(String who, String text) {
        synchronized (LOG) {
            LOG.add(new String[]{who, text});
            while (LOG.size() > 200) LOG.remove(0);
        }
        ChatActivity a = current;
        if (a != null && !a.isDestroyed()) a.runOnUiThread(() -> a.addBubble(who, text));
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.CREAM);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // الشريط العلوي
        LinearLayout top = new LinearLayout(this);
        top.setBackgroundColor(Ui.BROWN);
        top.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 8);
        top.setPadding(p * 2, p, p, p);
        TextView title = Ui.text(this, "🌰 بندق", 19, 0xFFFFFFFF, true);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button tasks = small("📋");
        tasks.setOnClickListener(v -> showTasks());
        voiceBtn = small(voiceLabel());
        voiceBtn.setOnClickListener(v -> {
            boolean on = !Store.getBool(this, Store.VOICE_ON, true);
            Store.putBool(this, Store.VOICE_ON, on);
            if (!on) Speaker.get(this).stop();
            voiceBtn.setText(voiceLabel());
        });
        Button reset = small("🧹");
        reset.setOnClickListener(v -> {
            Brain.reset();
            synchronized (LOG) {
                LOG.clear();
            }
            list.removeAllViews();
            addBubble("sys", "— بدأنا صفحة جديدة —");
        });
        Button settings = small("⚙️");
        settings.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
        top.addView(tasks);
        top.addView(voiceBtn);
        top.addView(reset);
        top.addView(settings);
        root.addView(top, new LinearLayout.LayoutParams(-1, -2));

        // الرسائل
        sv = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(p, p, p, p);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        // خانة الكتابة
        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setPadding(p, p, p, p);
        input = new EditText(this);
        input.setHint("اكتب لبندق…");
        input.setTextSize(16);
        input.setTextColor(Ui.INK);
        input.setMaxLines(4);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setBackground(Ui.round(this, 0xFFFFFFFF, 20, 0xFFE2CFB3));
        input.setPadding(p * 2, p, p * 2, p);
        input.setOnEditorActionListener((v, id, e) -> {
            if (id == EditorInfo.IME_ACTION_SEND
                    || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER && e.getAction() == KeyEvent.ACTION_DOWN)) {
                sendInput();
                return true;
            }
            return false;
        });
        bottom.addView(input, new LinearLayout.LayoutParams(0, -2, 1));
        Button mic = Ui.button(this, "🎤", Ui.ORANGE, Ui.INK);
        mic.setOnClickListener(v -> listen());
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-2, -2);
        mlp.setMarginStart(p);
        bottom.addView(mic, mlp);
        Button send = Ui.button(this, "إرسال", Ui.BROWN, 0xFFFFFFFF);
        send.setOnClickListener(v -> sendInput());
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.setMarginStart(p);
        bottom.addView(send, slp);
        root.addView(bottom, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        Ui.edgeToEdge(this, root);

        synchronized (LOG) {
            if (LOG.isEmpty()) {
                addBubble("sys", "اكتب أو اضغط 🎤 وتكلّم… أسئلة، أفكار، كود، أو «ذكّرني بعد ١٠ دقائق»");
            }
            for (String[] m : LOG) addBubble(m[0], m[1]);
        }
        if (busy) showThinking(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        current = this;
        voiceBtn.setText(voiceLabel());
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (current == this) current = null;
    }

    private String voiceLabel() {
        return Store.getBool(this, Store.VOICE_ON, true) ? "🔊" : "🔇";
    }

    private Button small(String t) {
        Button b = Ui.button(this, t, 0x00000000, 0xFFFFFFFF);
        b.setTextSize(18);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        return b;
    }

    void addBubble(String who, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(16);
        tv.setTextIsSelectable(true);
        tv.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        int p = Ui.dp(this, 10);
        tv.setPadding(p + 4, p, p + 4, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = Ui.dp(this, 6);
        int maxW = (int) (getResources().getDisplayMetrics().widthPixels * 0.8f);
        tv.setMaxWidth(maxW);
        switch (who) {
            case "user":
                tv.setTextColor(0xFF1F4E79);
                tv.setBackground(Ui.round(this, 0xFFE6F0FA, 18, 0));
                lp.gravity = Gravity.START; // يمين الشاشة
                break;
            case "bot":
                tv.setTextColor(Ui.INK);
                tv.setBackground(Ui.round(this, 0xFFFCEBD3, 18, 0));
                lp.gravity = Gravity.END;
                break;
            default:
                tv.setTextColor(Ui.MUTED);
                tv.setTextSize(13);
                lp.gravity = Gravity.CENTER_HORIZONTAL;
        }
        list.addView(tv, lp);
        sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
    }

    private void showThinking(boolean on) {
        if (on && thinkingView == null) {
            thinkingView = new TextView(this);
            thinkingView.setText("بندق يفكّر… 🤔");
            thinkingView.setTextColor(Ui.MUTED);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.gravity = Gravity.END;
            lp.topMargin = Ui.dp(this, 6);
            list.addView(thinkingView, lp);
            sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
        } else if (!on && thinkingView != null) {
            list.removeView(thinkingView);
            thinkingView = null;
        }
    }

    private void sendInput() {
        String t = input.getText().toString().trim();
        if (t.isEmpty()) return;
        if (send(t)) input.setText("");
    }

    private boolean send(String text) {
        if (busy) return false;
        if (Store.get(this, Store.API_KEY, "").trim().isEmpty()) {
            Toast.makeText(this, "ضع مفتاح API في الإعدادات أولاً 🔑", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, MainActivity.class));
            return false;
        }
        busy = true;
        record("user", text);
        showThinking(true);
        BuddyService s = BuddyService.instance;
        if (s != null) s.setThinking(true);

        final Context app = getApplicationContext();
        new Thread(() -> {
            String reply;
            boolean ok;
            try {
                reply = Brain.ask(app, text);
                ok = true;
            } catch (Exception e) {
                reply = Brain.errorText(e);
                ok = false;
            }
            final String r = reply;
            final boolean good = ok;
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                busy = false;
                ChatActivity a = current;
                if (a != null) a.showThinking(false);
                if (!isDestroyed()) showThinking(false);
                record("bot", r);
                BuddyService bs = BuddyService.instance;
                if (bs != null) {
                    bs.setThinking(false);
                    bs.say(r, false);
                }
                if (good) Speaker.get(app).say(app, r);
            });
        }).start();
        return true;
    }

    // ------------------------------------------------------------ الصوت
    private void listen() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "تكلّم مع بندق 🌰");
        Speaker.get(this).stop();
        try {
            startActivityForResult(i, REQ_SPEECH);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "التعرف على الصوت غير متوفر في جوالك", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SPEECH && res == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) send(r.get(0));
        }
    }

    // ------------------------------------------------------------ المهام
    private void showTasks() {
        JSONArray tasks = Store.arr(this, Store.TASKS);
        JSONArray rems = Store.arr(this, Store.REMINDERS);
        List<String> items = new ArrayList<>();
        List<int[]> map = new ArrayList<>(); // {النوع 0=مهمة 1=تذكير, الفهرس}
        for (int i = 0; i < tasks.length(); i++) {
            JSONObject o = tasks.optJSONObject(i);
            if (o == null) continue;
            items.add((o.optBoolean("done") ? "✅ " : "⬜ ") + o.optString("text"));
            map.add(new int[]{0, i});
        }
        SimpleDateFormat f = new SimpleDateFormat("EEE HH:mm", Locale.forLanguageTag("ar"));
        for (int i = 0; i < rems.length(); i++) {
            JSONObject o = rems.optJSONObject(i);
            if (o == null) continue;
            items.add("⏰ " + f.format(new Date(o.optLong("due"))) + " — " + o.optString("text"));
            map.add(new int[]{1, i});
        }
        AlertDialog.Builder d = new AlertDialog.Builder(this).setTitle("📋 مهامي وتذكيراتي");
        if (items.isEmpty()) {
            d.setMessage("ما فيه شيء بعد — قل لبندق: «أضف مهمة…» أو «ذكّرني…» 😊");
        } else {
            d.setItems(items.toArray(new String[0]), (dlg, which) -> itemOptions(map.get(which)));
        }
        d.setPositiveButton("تمام", null).show();
    }

    private void itemOptions(int[] m) {
        if (m[0] == 0) {
            new AlertDialog.Builder(this)
                    .setItems(new String[]{"✅ تم / تراجع", "🗑 حذف"}, (dlg, which) -> {
                        JSONArray t = Store.arr(this, Store.TASKS);
                        if (m[1] >= t.length()) return;
                        if (which == 0) {
                            JSONObject o = t.optJSONObject(m[1]);
                            boolean done = !o.optBoolean("done");
                            try {
                                o.put("done", done);
                            } catch (Exception ignored) {
                            }
                            Store.saveArr(this, Store.TASKS, t);
                            if (done) {
                                String[] cheers = {"كفو! 🎉", "ما شاء الله عليك 💪", "وحدة أقل! يلا اللي بعدها 🚀"};
                                String c = cheers[(int) (Math.random() * cheers.length)];
                                BuddyService s = BuddyService.instance;
                                if (s != null) s.celebrate(c);
                                else Toast.makeText(this, c, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            t.remove(m[1]);
                            Store.saveArr(this, Store.TASKS, t);
                        }
                        showTasks();
                    }).show();
        } else {
            JSONArray r = Store.arr(this, Store.REMINDERS);
            JSONObject o = r.optJSONObject(m[1]);
            if (o == null) return;
            new AlertDialog.Builder(this)
                    .setMessage("حذف التذكير؟\n" + o.optString("text"))
                    .setPositiveButton("حذف", (dlg, w) -> {
                        Reminders.remove(this, o.optInt("id"), true);
                        showTasks();
                    })
                    .setNegativeButton("إلغاء", null)
                    .show();
        }
    }
}
