package sa.fanoos.bunduq;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** جدولة التذكيرات والإشعارات. */
public final class Reminders {
    public static final String CH_BUDDY = "buddy";
    public static final String CH_REMIND = "reminders";

    private Reminders() {}

    public static void ensureChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel b = new NotificationChannel(CH_BUDDY, "بندق شغّال", NotificationManager.IMPORTANCE_MIN);
        NotificationChannel r = new NotificationChannel(CH_REMIND, "التذكيرات", NotificationManager.IMPORTANCE_HIGH);
        r.enableVibration(true);
        nm.createNotificationChannel(b);
        nm.createNotificationChannel(r);
    }

    public static int add(Context c, String text, long due) throws JSONException {
        int id = (int) (System.currentTimeMillis() % 1_000_000_000L);
        JSONArray a = Store.arr(c, Store.REMINDERS);
        a.put(new JSONObject().put("id", id).put("text", text).put("due", due));
        Store.saveArr(c, Store.REMINDERS, a);
        schedule(c, id, text, due);
        return id;
    }

    private static PendingIntent pi(Context c, int id, String text) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("id", id);
        i.putExtra("text", text);
        return PendingIntent.getBroadcast(c, id, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    public static void schedule(Context c, int id, String text, long due) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent p = pi(c, id, text);
        boolean exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms();
        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, p);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, p);
    }

    public static void remove(Context c, int id, boolean cancelAlarm) {
        JSONArray a = Store.arr(c, Store.REMINDERS);
        JSONArray keep = new JSONArray();
        String text = "";
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (o.optInt("id") == id) text = o.optString("text");
            else keep.put(o);
        }
        Store.saveArr(c, Store.REMINDERS, keep);
        if (cancelAlarm) c.getSystemService(AlarmManager.class).cancel(pi(c, id, text));
    }

    public static void rescheduleAll(Context c) {
        JSONArray a = Store.arr(c, Store.REMINDERS);
        long now = System.currentTimeMillis();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            schedule(c, o.optInt("id"), o.optString("text"), Math.max(now + 5000, o.optLong("due")));
        }
    }

    public static void notify(Context c, int id, String text) {
        ensureChannels(c);
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, ChatActivity.class),
                PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CH_REMIND)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("⏰ تذكير من بندق")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build();
        try {
            c.getSystemService(NotificationManager.class).notify(id, n);
        } catch (SecurityException ignored) {
            // إذن الإشعارات غير ممنوح
        }
    }
}
