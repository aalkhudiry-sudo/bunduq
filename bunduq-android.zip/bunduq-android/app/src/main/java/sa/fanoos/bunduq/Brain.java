package sa.fanoos.bunduq;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/** عقل بندق: محادثة مع Claude API مع أدوات للمهام والتذكيرات والملاحظات. */
public final class Brain {
    private static final String API = "https://api.anthropic.com/v1/messages";
    private static JSONArray history = new JSONArray();

    public static final class ApiError extends Exception {
        public final int code;
        public final String body;

        ApiError(int code, String body) {
            super("HTTP " + code);
            this.code = code;
            this.body = body == null ? "" : body;
        }
    }

    private static final String TOOLS = """
            [
             {"name":"add_reminder",
              "description":"ضبط تذكير. استخدم minutes لعدد الدقائق من الآن، أو time بصيغة HH:MM (24 ساعة).",
              "input_schema":{"type":"object","properties":{
                 "text":{"type":"string","description":"نص التذكير"},
                 "minutes":{"type":"number"},
                 "time":{"type":"string"}},"required":["text"]}},
             {"name":"add_task","description":"إضافة مهمة إلى قائمة مهام المستخدم.",
              "input_schema":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
             {"name":"complete_task","description":"تعليم مهمة كمنجزة برقمها كما يظهر في list_items.",
              "input_schema":{"type":"object","properties":{"number":{"type":"integer"}},"required":["number"]}},
             {"name":"list_items","description":"عرض المهام والتذكيرات والملاحظات المحفوظة.",
              "input_schema":{"type":"object","properties":{}}},
             {"name":"save_note","description":"حفظ معلومة دائمة طلب المستخدم أن تتذكرها.",
              "input_schema":{"type":"object","properties":{"note":{"type":"string"}},"required":["note"]}}
            ]
            """;

    private Brain() {}

    public static synchronized void reset() {
        history = new JSONArray();
    }

    private static String systemPrompt(Context c) {
        String now = new SimpleDateFormat("EEEE yyyy-MM-dd HH:mm", Locale.US).format(new Date());
        JSONArray notes = Store.arr(c, Store.NOTES);
        StringBuilder n = new StringBuilder();
        for (int i = 0; i < notes.length(); i++) n.append("- ").append(notes.optString(i)).append('\n');
        if (n.length() == 0) n.append("لا يوجد");
        return "أنت بندق، كائن كرتوني صغير على شكل حبة بندق، تعيش عائماً على شاشة جوال "
                + Store.userName(c) + ".\n"
                + "شخصيتك: مرح، خفيف دم، ذكي، متحمس، وتحب تساعد. تمزح أحياناً بلطف بدون مبالغة.\n"
                + "عن المستخدم: " + Store.get(c, Store.ABOUT_USER, Store.DEFAULT_ABOUT) + "\n"
                + "تكلّم بالعربي بلهجة سعودية بيضاء خفيفة، إلا إذا كلّمك بلغة أخرى.\n"
                + "ردودك قصيرة (جملة إلى ثلاث) لأنها تُقرأ بصوت عالٍ، إلا إذا طُلب شرح أو كود فأعطِ ما يلزم.\n"
                + "استخدم الأدوات لضبط التذكيرات والمهام والملاحظات عندما يطلب المستخدم ذلك، وأكّد له بعدها باختصار.\n"
                + "الوقت الآن: " + now + "\n"
                + "ملاحظات محفوظة عن المستخدم:\n" + n;
    }

    private static JSONObject call(Context c, JSONArray msgs) throws Exception {
        JSONObject body = new JSONObject()
                .put("model", Store.get(c, Store.MODEL, Store.DEFAULT_MODEL))
                .put("max_tokens", 1500)
                .put("system", systemPrompt(c))
                .put("tools", new JSONArray(TOOLS))
                .put("messages", msgs);

        HttpURLConnection con = (HttpURLConnection) new URL(API).openConnection();
        con.setRequestMethod("POST");
        con.setDoOutput(true);
        con.setConnectTimeout(20000);
        con.setReadTimeout(90000);
        con.setRequestProperty("x-api-key", Store.get(c, Store.API_KEY, "").trim());
        con.setRequestProperty("anthropic-version", "2023-06-01");
        con.setRequestProperty("content-type", "application/json");
        try (OutputStream os = con.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = con.getResponseCode();
        String s = readAll(code >= 400 ? con.getErrorStream() : con.getInputStream());
        con.disconnect();
        if (code >= 400) throw new ApiError(code, s);
        return new JSONObject(s);
    }

    private static String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    /** يُستدعى من خيط خلفي. */
    public static synchronized String ask(Context c, String text) throws Exception {
        JSONArray msgs = new JSONArray(history.toString());
        msgs.put(new JSONObject().put("role", "user").put("content", text));
        JSONObject resp = null;
        for (int round = 0; round < 6; round++) {
            resp = call(c, msgs);
            JSONArray content = resp.getJSONArray("content");
            msgs.put(new JSONObject().put("role", "assistant").put("content", content));
            if (!"tool_use".equals(resp.optString("stop_reason"))) break;
            JSONArray results = new JSONArray();
            for (int j = 0; j < content.length(); j++) {
                JSONObject b = content.getJSONObject(j);
                if ("tool_use".equals(b.optString("type"))) {
                    JSONObject in = b.optJSONObject("input");
                    String out = runTool(c, b.getString("name"), in == null ? new JSONObject() : in);
                    results.put(new JSONObject().put("type", "tool_result")
                            .put("tool_use_id", b.getString("id")).put("content", out));
                }
            }
            msgs.put(new JSONObject().put("role", "user").put("content", results));
        }

        StringBuilder reply = new StringBuilder();
        JSONArray content = resp.getJSONArray("content");
        for (int j = 0; j < content.length(); j++) {
            JSONObject b = content.getJSONObject(j);
            if ("text".equals(b.optString("type"))) reply.append(b.optString("text"));
        }

        // احتفظ بآخر المحادثة فقط، وابدأ دائماً برسالة نصية من المستخدم
        if (msgs.length() > 30) {
            for (int i = msgs.length() - 30; i < msgs.length(); i++) {
                JSONObject m = msgs.getJSONObject(i);
                if ("user".equals(m.optString("role")) && m.opt("content") instanceof String) {
                    JSONArray trimmed = new JSONArray();
                    for (int k = i; k < msgs.length(); k++) trimmed.put(msgs.get(k));
                    msgs = trimmed;
                    break;
                }
            }
        }
        history = msgs;
        String r = reply.toString().trim();
        return r.isEmpty() ? "تم 👍" : r;
    }

    public static String errorText(Exception e) {
        if (e instanceof ApiError) {
            ApiError a = (ApiError) e;
            String b = a.body.toLowerCase(Locale.US);
            if (a.code == 401) return "مفتاح API غير صحيح 🔑 افتح تطبيق بندق وصحّحه.";
            if (a.code == 429) return "تعبت شوي 😅 كثرت الطلبات، جرّب بعد دقيقة.";
            if (b.contains("credit")) return "الرصيد في حساب Claude API خلص، اشحنه من console.anthropic.com";
            if (a.code == 404 || b.contains("model")) return "اسم الموديل غير متاح، صحّحه من شاشة الإعدادات.";
            return "صار خطأ (" + a.code + ") 🤕";
        }
        return "ما قدرت أتصل بالإنترنت 📡 تأكد من الاتصال وجرّب مرة ثانية.";
    }

    // ------------------------------------------------------------ الأدوات
    static String runTool(Context c, String name, JSONObject in) {
        try {
            switch (name) {
                case "add_reminder": {
                    long now = System.currentTimeMillis();
                    long due;
                    if (in.has("minutes")) {
                        due = now + (long) (in.getDouble("minutes") * 60000);
                    } else if (in.has("time")) {
                        String[] hm = in.getString("time").trim().split(":");
                        Calendar cal = Calendar.getInstance();
                        cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hm[0].trim()));
                        cal.set(Calendar.MINUTE, hm.length > 1 ? Integer.parseInt(hm[1].trim()) : 0);
                        cal.set(Calendar.SECOND, 0);
                        cal.set(Calendar.MILLISECOND, 0);
                        if (cal.getTimeInMillis() <= now) cal.add(Calendar.DAY_OF_MONTH, 1);
                        due = cal.getTimeInMillis();
                    } else {
                        return "خطأ: حدد minutes أو time";
                    }
                    String text = in.getString("text");
                    int id = Reminders.add(c, text, due);
                    return "تم ضبط التذكير رقم " + id + " الساعة "
                            + new SimpleDateFormat("HH:mm yyyy-MM-dd", Locale.US).format(new Date(due));
                }
                case "add_task": {
                    JSONArray t = Store.arr(c, Store.TASKS);
                    t.put(new JSONObject().put("text", in.getString("text")).put("done", false));
                    Store.saveArr(c, Store.TASKS, t);
                    return "أضيفت المهمة رقم " + t.length();
                }
                case "complete_task": {
                    JSONArray t = Store.arr(c, Store.TASKS);
                    int i = in.getInt("number") - 1;
                    if (i < 0 || i >= t.length()) return "لا توجد مهمة بهذا الرقم";
                    t.getJSONObject(i).put("done", true);
                    Store.saveArr(c, Store.TASKS, t);
                    return "تم تعليمها كمنجزة";
                }
                case "list_items": {
                    JSONArray t = Store.arr(c, Store.TASKS);
                    JSONArray tasks = new JSONArray();
                    for (int i = 0; i < t.length(); i++) {
                        JSONObject o = t.getJSONObject(i);
                        tasks.put((i + 1) + ". " + (o.optBoolean("done") ? "✅ " : "⬜ ") + o.optString("text"));
                    }
                    JSONArray r = Store.arr(c, Store.REMINDERS);
                    JSONArray rems = new JSONArray();
                    SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
                    for (int i = 0; i < r.length(); i++) {
                        JSONObject o = r.getJSONObject(i);
                        rems.put("⏰ " + f.format(new Date(o.getLong("due"))) + " — " + o.optString("text"));
                    }
                    return new JSONObject().put("tasks", tasks).put("reminders", rems)
                            .put("notes", Store.arr(c, Store.NOTES)).toString();
                }
                case "save_note": {
                    JSONArray n = Store.arr(c, Store.NOTES);
                    n.put(in.getString("note"));
                    while (n.length() > 40) n.remove(0);
                    Store.saveArr(c, Store.NOTES, n);
                    return "حُفظت الملاحظة";
                }
                default:
                    return "أداة غير معروفة";
            }
        } catch (JSONException | RuntimeException e) {
            return "خطأ: " + e.getMessage();
        }
    }
}
