package sa.fanoos.bunduq;

import android.content.Context;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

/** صوت بندق: محرك النطق في الجوال باللغة العربية. */
public final class Speaker implements TextToSpeech.OnInitListener {
    private static Speaker inst;
    private final TextToSpeech tts;
    private boolean ready;

    public static synchronized Speaker get(Context c) {
        if (inst == null) inst = new Speaker(c.getApplicationContext());
        return inst;
    }

    private Speaker(Context c) {
        tts = new TextToSpeech(c, this);
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) return;
        int r = tts.setLanguage(Locale.forLanguageTag("ar-SA"));
        if (r < 0) r = tts.setLanguage(Locale.forLanguageTag("ar"));
        ready = r >= 0;
        tts.setSpeechRate(1.05f);
        tts.setPitch(1.25f); // صوت أخف وألطف
    }

    public void say(Context c, String text) {
        if (!ready || !Store.getBool(c, Store.VOICE_ON, true) || text == null) return;
        String t = text.replaceAll("(?s)```.*?```", " ")
                .replaceAll("[*_#`>|]", "")
                .replaceAll("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}]", "")
                .trim();
        if (t.length() > 500) t = t.substring(0, 500);
        if (t.isEmpty()) return;
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "b" + System.currentTimeMillis());
    }

    public void stop() {
        tts.stop();
    }
}
