package sa.fanoos.bunduq;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.TextView;

import java.util.Random;

/** خدمة تُبقي بندق عائماً فوق كل التطبيقات. */
public class BuddyService extends Service {
    public static BuddyService instance;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private WindowManager wm;
    private BuddyView buddy;
    private WindowManager.LayoutParams lp;
    private TextView bubble;
    private WindowManager.LayoutParams blp;
    private boolean bubbleShown, dragging;
    private ValueAnimator walk;

    private final Runnable hideBubble = this::removeBubble;
    private final Runnable wander = new Runnable() {
        @Override
        public void run() {
            if (Store.getBool(BuddyService.this, Store.WANDER_ON, true) && !dragging && !bubbleShown) {
                walkTo(clampX(lp.x + (rnd.nextBoolean() ? 1 : -1) * Ui.dp(BuddyService.this, 40 + rnd.nextInt(90))));
            }
            h.postDelayed(this, 12000 + rnd.nextInt(14000));
        }
    };

    public static boolean isRunning() {
        return instance != null;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startAsForeground();
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        instance = this;
        wm = getSystemService(WindowManager.class);

        buddy = new BuddyView(this);
        lp = new WindowManager.LayoutParams(buddy.widthPx(), buddy.heightPx(),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        lp.x = dm.widthPixels - buddy.widthPx() - Ui.dp(this, 12);
        lp.y = dm.heightPixels / 2;
        buddy.setOnTouchListener(new Drag());
        wm.addView(buddy, lp);

        buildBubble();
        h.postDelayed(() -> {
            buddy.jump();
            say("هلا يا " + Store.userName(this) + "! أنا بندق 🌰 اضغط علي ونسولف", false);
        }, 600);
        h.postDelayed(wander, 15000);
    }

    private void startAsForeground() {
        Reminders.ensureChannels(this);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, ChatActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, BuddyService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, Reminders.CH_BUDDY)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("بندق معك 🌰")
                .setContentText("اضغط لفتح الدردشة")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, R.drawable.ic_notif), "إيقاف بندق", stop).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        instance = null;
        h.removeCallbacksAndMessages(null);
        if (walk != null) walk.cancel();
        try {
            if (buddy != null && buddy.isAttachedToWindow()) wm.removeView(buddy);
        } catch (Exception ignored) {
        }
        removeBubble();
        super.onDestroy();
    }

    // ------------------------------------------------------------ اللمس
    private class Drag implements View.OnTouchListener {
        private float sx, sy;
        private int ox, oy;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    sx = e.getRawX();
                    sy = e.getRawY();
                    ox = lp.x;
                    oy = lp.y;
                    dragging = false;
                    if (walk != null) walk.cancel();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                    if (!dragging && Math.hypot(dx, dy) > Ui.dp(BuddyService.this, 8)) dragging = true;
                    if (dragging) {
                        lp.x = clampX(ox + (int) dx);
                        lp.y = Math.max(0, oy + (int) dy);
                        wm.updateViewLayout(buddy, lp);
                        placeBubble();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!dragging) {
                        buddy.jump();
                        openChat();
                    }
                    dragging = false;
                    return true;
                default:
                    return false;
            }
        }
    }

    private int clampX(int x) {
        int max = getResources().getDisplayMetrics().widthPixels - buddy.widthPx();
        return Math.max(0, Math.min(max, x));
    }

    private void walkTo(int target) {
        if (walk != null) walk.cancel();
        walk = ValueAnimator.ofInt(lp.x, target);
        walk.setDuration(Math.max(800, Math.abs(target - lp.x) * 12L));
        walk.setInterpolator(new AccelerateDecelerateInterpolator());
        walk.addUpdateListener(a -> {
            if (buddy == null || !buddy.isAttachedToWindow()) return;
            lp.x = (int) a.getAnimatedValue();
            wm.updateViewLayout(buddy, lp);
        });
        walk.start();
    }

    private void openChat() {
        Intent i = new Intent(this, ChatActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------ الفقاعة
    private void buildBubble() {
        bubble = new TextView(this);
        bubble.setTextSize(15);
        bubble.setTextColor(Ui.INK);
        bubble.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        bubble.setMaxWidth(Ui.dp(this, 240));
        int pad = Ui.dp(this, 10);
        bubble.setPadding(pad + 2, pad, pad + 2, pad);
        bubble.setBackground(Ui.round(this, Ui.CREAM, 16, Ui.BROWN));
        bubble.setOnClickListener(v -> openChat());
        blp = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        blp.gravity = Gravity.TOP | Gravity.START;
    }

    private void placeBubble() {
        if (!bubbleShown) return;
        bubble.measure(View.MeasureSpec.makeMeasureSpec(Ui.dp(this, 240), View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int bw = bubble.getMeasuredWidth(), bh = bubble.getMeasuredHeight();
        int sw = getResources().getDisplayMetrics().widthPixels;
        blp.x = Math.max(Ui.dp(this, 4), Math.min(sw - bw - Ui.dp(this, 4), lp.x + buddy.widthPx() / 2 - bw / 2));
        blp.y = lp.y - bh + Ui.dp(this, 14);
        if (blp.y < 0) blp.y = lp.y + buddy.heightPx();
        try {
            wm.updateViewLayout(bubble, blp);
        } catch (Exception ignored) {
        }
    }

    private void removeBubble() {
        if (bubbleShown) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubbleShown = false;
        }
    }

    /** يعرض كلاماً في الفقاعة، وينطقه إذا speak = true. */
    public void say(String text, boolean speak) {
        String shown = text.length() < 200 ? text : text.substring(0, 200) + "…";
        bubble.setText(shown);
        if (!bubbleShown) {
            try {
                wm.addView(bubble, blp);
                bubbleShown = true;
            } catch (Exception ignored) {
                return;
            }
        }
        placeBubble();
        long dur = Math.min(14000, 4000 + shown.length() * 55L);
        buddy.talk(Math.min(dur, 2000 + shown.length() * 40L));
        h.removeCallbacks(hideBubble);
        h.postDelayed(hideBubble, dur);
        if (speak) Speaker.get(this).say(this, text);
    }

    public void alert(String text) {
        buddy.jump();
        h.postDelayed(buddy::jump, 1000);
        say(text, true);
        h.removeCallbacks(hideBubble);
        h.postDelayed(hideBubble, 30000);
    }

    public void setThinking(boolean b) {
        if (buddy != null) buddy.setThinking(b);
    }

    public void celebrate(String text) {
        buddy.jump();
        say(text, true);
    }
}
