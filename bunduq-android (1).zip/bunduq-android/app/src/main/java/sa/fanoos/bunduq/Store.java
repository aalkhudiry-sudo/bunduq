package sa.fanoos.bunduq;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

/** تخزين بسيط للإعدادات والمهام والتذكيرات والملاحظات. */
public final class Store {
    public static final String API_KEY = "api_key";
    public static final String MODEL = "model";
    public static final String PROVIDER = "provider";
    public static final String BASE_URL = "base_url";
    public static final String USER_NAME = "user_name";
    public static final String ABOUT_USER = "about_user";
    public static final String VOICE_ON = "voice_on";
    public static final String WANDER_ON = "wander_on";
    public static final String TASKS = "tasks";
    public static final String REMINDERS = "reminders";
    public static final String NOTES = "notes";

    public static final String DEFAULT_MODEL = "claude-haiku-5-5";
    public static final String DEFAULT_BASE = "https://api.openai.com/v1";
    public static final String DEFAULT_NAME = "عبد المحسن";
    public static final String DEFAULT_ABOUT = "يبرمج ويصمم ألعاب بكسل آرت في استوديو فانوس.";

    private Store() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("bunduq", Context.MODE_PRIVATE);
    }

    public static String get(Context c, String k, String def) {
        return p(c).getString(k, def);
    }

    public static void put(Context c, String k, String v) {
        p(c).edit().putString(k, v).apply();
    }

    public static boolean getBool(Context c, String k, boolean def) {
        return p(c).getBoolean(k, def);
    }

    public static void putBool(Context c, String k, boolean v) {
        p(c).edit().putBoolean(k, v).apply();
    }

    public static synchronized JSONArray arr(Context c, String k) {
        try {
            return new JSONArray(get(c, k, "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    public static synchronized void saveArr(Context c, String k, JSONArray a) {
        p(c).edit().putString(k, a.toString()).commit();
    }

    public static String userName(Context c) {
        String n = get(c, USER_NAME, DEFAULT_NAME).trim();
        return n.isEmpty() ? DEFAULT_NAME : n;
    }
}
