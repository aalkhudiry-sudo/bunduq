package sa.fanoos.bunduq;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** شاشة الإعداد: الأذونات، مفتاح API، تشغيل وإيقاف بندق. */
public class MainActivity extends Activity {
    private EditText key, name, about, model, baseUrl;
    private TextView keyHint;
    private Button providerBtn;
    private String provider = "claude";
    private Button overlayBtn, alarmBtn, startBtn;
    private CheckBox wander, voice;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Reminders.ensureChannels(this);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.CREAM);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        int pad = Ui.dp(this, 20);
        col.setPadding(pad, pad, pad, pad);
        sv.addView(col);

        TextView title = Ui.text(this, "🌰 بندق", 30, Ui.BROWN, true);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(title, full());
        TextView sub = Ui.text(this, "رفيقك الذكي العائم على الشاشة", 15, Ui.MUTED, false);
        sub.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(sub, full());

        section(col, "١. الأذونات");
        overlayBtn = Ui.button(this, "", Ui.ORANGE, Ui.INK);
        overlayBtn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()))));
        col.addView(overlayBtn, gap(full(), 6));
        alarmBtn = Ui.button(this, "", Ui.ORANGE, Ui.INK);
        alarmBtn.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        col.addView(alarmBtn, gap(full(), 6));

        section(col, "٢. العقل (الذكاء الاصطناعي)");
        provider = Store.get(this, Store.PROVIDER, "claude");
        providerBtn = Ui.button(this, "", Ui.ORANGE, Ui.INK);
        providerBtn.setOnClickListener(v -> cycleProvider());
        col.addView(providerBtn, gap(full(), 6));
        key = field(col, "مفتاح API", Store.get(this, Store.API_KEY, ""));
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        keyHint = Ui.text(this, "", 13, Ui.MUTED, false);
        col.addView(keyHint, full());
        baseUrl = field(col, "رابط المزوّد (للمتوافق مع OpenAI فقط)",
                Store.get(this, Store.BASE_URL, Store.DEFAULT_BASE));
        model = field(col, "الموديل", Store.get(this, Store.MODEL, Store.DEFAULT_MODEL));
        refreshProvider();

        section(col, "٣. عنك");
        name = field(col, "اسمك", Store.userName(this));
        about = field(col, "نبذة عنك يعرفها بندق", Store.get(this, Store.ABOUT_USER, Store.DEFAULT_ABOUT));

        voice = new CheckBox(this);
        voice.setText("🔊 بندق يتكلم بصوت");
        voice.setChecked(Store.getBool(this, Store.VOICE_ON, true));
        col.addView(voice, gap(full(), 10));
        wander = new CheckBox(this);
        wander.setText("🚶 بندق يتمشى على الشاشة");
        wander.setChecked(Store.getBool(this, Store.WANDER_ON, true));
        col.addView(wander, full());

        startBtn = Ui.button(this, "", Ui.BROWN, 0xFFFFFFFF);
        startBtn.setTextSize(18);
        startBtn.setOnClickListener(v -> toggleBuddy());
        col.addView(startBtn, gap(full(), 24));

        Button chat = Ui.button(this, "💬 فتح الدردشة", Ui.ORANGE, Ui.INK);
        chat.setOnClickListener(v -> {
            save();
            startActivity(new Intent(this, ChatActivity.class));
        });
        col.addView(chat, gap(full(), 10));

        TextView credit = Ui.text(this, "Fanoos Studio © 2026\nfanoos.studio.sa@gmail.com", 12, Ui.MUTED, false);
        credit.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(credit, gap(full(), 30));

        setContentView(sv);
        Ui.edgeToEdge(this, sv);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        save();
    }

    private void refresh() {
        boolean ov = Settings.canDrawOverlays(this);
        overlayBtn.setText(ov ? "✅ مسموح له يظهر فوق التطبيقات" : "اسمح لبندق يظهر فوق التطبيقات");
        overlayBtn.setEnabled(!ov);
        boolean exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                || getSystemService(AlarmManager.class).canScheduleExactAlarms();
        alarmBtn.setText(exact ? "✅ التذكيرات في وقتها بالضبط" : "اسمح بالتذكير في الوقت المحدد بالضبط");
        alarmBtn.setEnabled(!exact);
        startBtn.setText(BuddyService.isRunning() ? "⏹ إيقاف بندق" : "▶️ تشغيل بندق");
    }

    private void save() {
        Store.put(this, Store.PROVIDER, provider);
        Store.put(this, Store.BASE_URL, baseUrl.getText().toString().trim());
        Store.put(this, Store.API_KEY, key.getText().toString().trim());
        String m = model.getText().toString().trim();
        Store.put(this, Store.MODEL, m.isEmpty() ? Store.DEFAULT_MODEL : m);
        Store.put(this, Store.USER_NAME, name.getText().toString().trim());
        Store.put(this, Store.ABOUT_USER, about.getText().toString().trim());
        Store.putBool(this, Store.VOICE_ON, voice.isChecked());
        Store.putBool(this, Store.WANDER_ON, wander.isChecked());
    }

    private void toggleBuddy() {
        save();
        if (BuddyService.isRunning()) {
            stopService(new Intent(this, BuddyService.class));
            startBtn.postDelayed(this::refresh, 300);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "اسمح لبندق يظهر فوق التطبيقات أولاً", Toast.LENGTH_LONG).show();
            overlayBtn.performClick();
            return;
        }
        if (key.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "بندق بيشتغل، لكن يحتاج مفتاح API عشان يفكر 🧠", Toast.LENGTH_LONG).show();
        }
        startForegroundService(new Intent(this, BuddyService.class));
        startBtn.postDelayed(this::refresh, 500);
        moveTaskToBack(true);
    }

    private void cycleProvider() {
        provider = "claude".equals(provider) ? "gemini" : "gemini".equals(provider) ? "openai" : "claude";
        model.setText(defaultModel(provider));
        refreshProvider();
    }

    private void refreshProvider() {
        String label;
        String hint;
        switch (provider) {
            case "gemini":
                label = "Google Gemini";
                hint = "مجاني: احصل على المفتاح من aistudio.google.com/apikey";
                break;
            case "openai":
                label = "OpenAI متوافق";
                hint = "أي مزوّد يدعم واجهة OpenAI، مثل OpenAI أو Groq أو DeepSeek. ضع رابطه ونموذجه.";
                break;
            default:
                label = "Claude (Anthropic)";
                hint = "مدفوع: احصل على المفتاح من console.anthropic.com";
                break;
        }
        providerBtn.setText("المزوّد: " + label + "  ⟳");
        keyHint.setText(hint);
    }

    private static String defaultModel(String p) {
        switch (p) {
            case "gemini":
                return "gemini-2.5-flash";
            case "openai":
                return "gpt-4o-mini";
            default:
                return Store.DEFAULT_MODEL;
        }
    }

    // ------------------------------------------------------------ مساعدات
    private LinearLayout.LayoutParams full() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams gap(LinearLayout.LayoutParams p, int topDp) {
        p.topMargin = Ui.dp(this, topDp);
        return p;
    }

    private void section(LinearLayout col, String s) {
        col.addView(Ui.text(this, s, 17, Ui.INK, true), gap(full(), 22));
    }

    private EditText field(LinearLayout col, String hint, String value) {
        TextView label = Ui.text(this, hint, 13, Ui.MUTED, false);
        col.addView(label, gap(full(), 8));
        EditText e = new EditText(this);
        e.setText(value);
        e.setSingleLine(false);
        e.setTextSize(15);
        e.setTextColor(Ui.INK);
        e.setBackground(Ui.round(this, 0xFFFFFFFF, 12, 0xFFE2CFB3));
        int p = Ui.dp(this, 10);
        e.setPadding(p, p, p, p);
        col.addView(e, gap(full(), 4));
        return e;
    }
}
